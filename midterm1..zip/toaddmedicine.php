<?php

    $redirect = "index.php";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        include "db.php";

        if(isset($_POST['name']) && isset($_POST['manufacturer']) && isset($_POST['price'])){

          

            addMedicine($_POST['name'], $_POST['manufacturer'], $_POST['price']);

        }
    }
      header("Location:$redirect");  

?>