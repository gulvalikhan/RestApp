        <?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <table class="tabbe table striped">
                       <thead>
                            <tr>
                                <td>ID</td>
                                <td>NAME</td>
                                <td>MANUFACTURER</td>
                                <td>PRICE</td>
                                <td width="7%">DETAILS</td>
                            </tr>
                       </thead>
                       <tbody>
                            <?php
                            
                                $medicines = getMedicine();
                                if($medicines!=null){
                                    foreach($medicines as $medicine){
                            ?>
                                <tr>
                                    <td><?php echo $medicine['id'];?></td>
                                    <td><?php echo $medicine['name'];?></td>
                                    <td><?php echo $medicine['manufacturer'];?></td>
                                    <td><?php echo $medicine['price'];?></td>
                                    <td><a href="details.php?id=<?php echo $medicine['id'];?>" class="btn btn-primary btn-sm">DETAILS</a></td>

                                </tr>
                                <?php
                                        }
                                    }
                                ?>
                       </tbody>
                    </table>
                 </div>
             </div>
         </div>
    </body>
</html>