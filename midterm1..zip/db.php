<?php

    try{

        $connection = new PDO("mysql:host=localhost;dbname=gul1", "root", "");
    
    }catch(Exception $e){

        echo "<h5  style = 'color: red;'>".$e->getMessege()."</h5>";
    }

    function getMedicine(){

        global $connection;

        $query = $connection->prepare("SELECT * FROM medicine");

        $query->execute();

        $result = $query->fetchAll();

        return $result;
    }

    function addMedicine($name, $price, $manufacturer){

        global $connection;

        $query = $connection->prepare("
            INSERT INTO medicine(id, name, manufacturer, price)
            VALUES(NULL, :n, :m, :p)
        ");

        $query->execute(array("n"=>$name, "m"=>$manufacturer,"p"=>$price));

    }

    function getMedi($id){

        global $connection;

        $query = $connection->prepare("SELECT * FROM medicine WHERE id = :id");
        $query->execute(array("id"=>$id));
        $result = $query->fetch();


        return $result;
    }

    function updateMedicine($id, $name, $manufacturer, $price){

        global $connection;

        $query = $connection->prepare("
            UPDATE medicine SET name = :n, price = :p, manufacturer = :m WHERE id = :i
        ");

        $query->execute(array("n"=>$name, "p"=>$price, "m"=>$manufacturer, "i"=>$id));

    }

    function deleteMedicine($id){

        global $connection;

        $query = $connection->prepare("
            DELETE FROM medicine WHERE id = :i 
        ");

        $query->execute(array("i"=>$id));

    }
?>