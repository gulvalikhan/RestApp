<div class="container">
            <div class="row">
                <div class="col-12">
                <nav class="navbar navbar-expand-lg bg btn btn-dark">
                  <div class="container-fluid">
                    <a class="navbar-brand" href="index.php">MEDICINES</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                      <div class="navbar-nav">
                        <a class="nav-link active" href="index.php">Home</a>
                        <a class="nav-link" href="addmedicine.php">ADD MEDICINES</a>
                      </div>
                    </div>
                  </div>
                </nav>
         </div>
     </div>
</div>
