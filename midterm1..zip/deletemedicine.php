<?php

    $redirect = "index.php";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        require_once 'db.php';

        if(isset($_POST['id'])){

           $medicine = getMedicine($_POST['id']);

           if($medicine!=null){

            deleteMedicine($_POST['id']);

           }
        }

    }
    
    header("Location:$redirect");
  
?>