<?php

    try{


    $connection = new PDO("mysql:host=localhost;dbname=gul","root","");

    }catch(Exception $e) {
    echo "<h4 style = 'color:red;'>".$e->getMessage()."</h4>";

     }

    function getALLItems() {

    global $connection;

    $query = $connection->prepare("SELECT *FROM items");

    $query->execute();
    $result = $query->fetchALL();

    return $result;
     }



     function addItem($name,$manufacturer,$price){

            global $connection;
    
            $query = $connection->prepare("
                INSERT INTO items(id, name, price, manufacturer)
                VALUES(NULL, :n, :p, :m)
            ");

        
            $query->execute(array("n"=>$name, "p"=>$price, "m"=>$manufacturer));
        }


        function getItem($id) {

            global $connection;
        
            $query = $connection->prepare("SELECT *FROM items WHERE ID=:ID");
            $query->execute(array("ID"=>$id));
            $result = $query->fetch();
        
            return $result;
             }
    
 ?>



