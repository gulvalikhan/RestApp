<div class = "container-fluid bg dark py-3">
    <div class = row mt-3>
        <div class = col-12>
            <p class = "text-center text-light">
                Copyright &copy; 2022.
            </p>
        </div>
    </div>
</div>