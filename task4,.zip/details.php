<?php 
 
require_once 'db.php'; 
 
 ?> 
 
<!DOCTYPE html> 
<html> 
    <head> 
        <title></title> 
        <?php require_once 'head.php'; 
         ?> 
    </head> 
   <body> 
   <?php 
     require_once 'navbar.php'; 
            ?> 
            <div class = "container" style = "min-height:600px;"> 
                <div class = row mt-3> 
                    <div class = col-6 mx-auto> 
                        <?php 
 
                        if(isset($_GET['ID']) && is_numeric($_GET['ID'])){ 
 
                            $item = getItem($_GET['ID']); 
                             
                            if($item!=null){ 
                            }
                        }
                         
 
                             
                         ?> 
                         
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <label>NAME :</label> 
                     
                            </div> 
                                </div> 
 
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                  <input type="text" class="form-control" readonly value=" 
                                    <?php echo  $item['NAME'];?>">  
                                </div> 
                            </div> 
 
 
 
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <label>MANUFACTURER :</label> 
                     
                                </div> 
 
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <input type="text" class="form-control" readonly value=" 
                                    <?php echo  $item['MANUFACTURER'];?>">  
                                </div> 
                            </div> 
 
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <label>PRICE :</label> 
                     
                                </div> 
                                <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <input type="number" class="form-control" readonly value=" 
                                    <?php echo  $item['PRICE'];?>"> 
                                </div> 
                            </div> 
 
                            <div class="row mt-3"> 
                                <div class="col-12"> 
                                    <button class= "btn btn-success">EDIT ITEM</button> 
                                </div> 
                            </div> 
 
                           <?php 
                         
                           ?> 
 
                             
                         
 
                    </div> 
 
                </div> 
 
            </div> 
       <?php 
         require_once 'footer.php'; 
        ?> 
 
   </body> 
</html>