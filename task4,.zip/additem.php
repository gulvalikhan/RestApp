<?php

require_once 'db.php';

 ?>

<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <?php require_once 'head.php';
         ?>
    </head>
   <body>
   <?php
     require_once 'navbar.php';
            ?>
            <div class = "container" style = "min-height:600px;">
                <div class = row mt-3>
                    <div class = col-6 mx-auto>
                        <form action ="toadditem.php" method=post>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>NAME :</label>
                                </div>

                            <div class="row mt-3">
                                <div class="col-12">
                                    <input type="text" class="form-control" name="name" required placeholder="Insert name"> 
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>MANUFACTURER :</label>
                                </div>

                            <div class="row mt-3">
                                <div class="col-12">
                                    <input type="text" class="form-control" name="manufacturer" required placeholder="Insert manufacturer"> 
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>PRICE :</label>
                                </div>
                                <div class="row mt-3">
                                <div class="col-12">
                                    <input type="text" class="form-control" name="price" required placeholder="Insert price"> 
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-12">
                                    <button class= "btn btn-success">ADD ITEM</button>
                                </div>
                            </div>



                        </form>
                        
                    </div>

                </div>

            </div>
       <?php
         require_once 'footer.php';
        ?>

   </body>
</html>