<?php

require_once 'db.php';

 ?>

<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <?php require_once 'head.php';
         ?>
    </head>
   <body>
   <?php
     require_once 'navbar.php';
            ?>
            <div class = "container" style = "min-height:600px;">
                <div class = row mt-3>
                    <div class = col-12>
                        <table class = "table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NAME</th>
                                <th>MANUFACTURER</th>
                                <th>PRICE</th>
                                <th width = "7%;"> DETAILS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $items = getALLItems();
                            if($items!=null){
                                foreach($items as $item){
                                    ?>
                                    <tr>
                                        <td><?php echo $item['ID']; ?></td>
                                        <td><?php echo $item['NAME']; ?></td>
                                        <td><?php echo $item['MANUFACTURER']; ?></td>
                                        <td><?php echo $item['PRICE'];  ?></td>
                                        <td><a href="details.php?id=<?php echo $item['ID'];
                                        ?>" class="btn btn-primary btn-sm">DETAILS</a></td>
                                    </tr>

                                    <?php

                                }
                            }
                            
                            ?>
                        </tbody>

                        </table>
                    </div>

                </div>

            </div>
       <?php
         require_once 'footer.php';
        ?>

   </body>
</html>