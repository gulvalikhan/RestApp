<?php

    if($_SERVER['REQUEST_METHOD']==='POST'){

        if(isset($_POST['name']) && isset($_POST['manufacturer']) && isset($_POST['price'])){

            require_once "db.php";

            addItem($_POST['name'],$_POST['manufacturer'],$_POST['price']);



        }
    }

    header("Location:index.php");

 ?>