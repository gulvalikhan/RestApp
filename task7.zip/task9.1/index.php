<!DOCTYPE html>
<html>
    <head>
	
    </head>
    <body>
    	<?php
    	    if(isset($_COOKIE['name'])){
    	    	echo $_COOKIE['name'];
    	    }
    	?>
	  
	    <form action="setcookie.php" method="post">
	    	Name of a Site : <input type="text" name="name">
	    	<button>Set Site Name</button>
	    </form>		
    </body>
</html>