<?php

    if($_SERVER['REQUEST_METHOD']==='POST'){

    	setcookie("name", $_POST['name'], time()+3600);


    }
    header("Location:index.php");
                                                                                                                
?>