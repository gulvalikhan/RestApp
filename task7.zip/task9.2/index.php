<!DOCTYPE html>
<html>
    <head>
	
    </head>
    <body>
    	<?php
    	    if(isset($_COOKIE['user_name']) && isset($_COOKIE['user_surname']) && isset($_COOKIE['user_age']) && isset($_COOKIE['user_country']) && isset($_COOKIE['user_gender']) && isset($_COOKIE['user_credit_card'])){
    	    	echo $_COOKIE['user_name']." ".$_COOKIE['user_surname']." ".$_COOKIE['user_age']." ".$_COOKIE['user_country']." ".$_COOKIE['user_gender']." ".$_COOKIE['user_creditcard'];
    	    }
    	?>
	  
	    <form action="setcookie.php" method="post">
	    
	    	<br>Name : <input type="text" name="name"></br>
	    	<br>Surname : <input type="text" name="surname"></br>
	    	<br>Age : 
	    	<input type="number" name="age"></br>
            </br>
            <br>Country :
            <input type="text" name="country">
            </br>
            <br>Gender :
              <input value = Male type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>Male
              <input value = Female type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>Female
            </br>
            <br>Credit Card :
            <input type="number" name="creditcard"></br>
            </br>
	    	<br><button>SAVE</button></br>
	    </form>	
    </body>
</html>