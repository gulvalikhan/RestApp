<?php

    if($_SERVER['REQUEST_METHOD']==='POST'){

    	setcookie("user_name", $_POST['name'], time()+(86400*30));
    	setcookie("user_surname", $_POST['surname'], time()+(86400*30));
        setcookie("user_age", $_POST['age'], time()+(86400*30));
        setcookie("user_country", $_POST['country'], time()+(86400*30));
        setcookie("user_gender", $_POST['flexRadioDefault'], time()+(86400*30));
        setcookie("user_creditcard", $_POST['creditcard'], time()+(86400*30));



    }
    header("Location:index.php");

?>