public class Qwer {
    private TV_set[] Baza = new TV_set[1000];
    private int sizeOfTv_set = 0;

    public Qwer() {
    }

    public void addNewTV_set(TV_set televizor) {
        this.Baza[this.sizeOfTv_set] = televizor;
        ++this.sizeOfTv_set;
    }

    public void printAllTV_set() {
        for(int i = 0; i < this.sizeOfTv_set; ++i) {
            if (!this.Baza[i].getisDeleted() && !this.Baza[i].getisSold()) {
                System.out.println(this.Baza[i].getTV_setData());
            }
        }

    }

    public void iskatPoImeni(String name) {
        for(int i = 0; i < this.sizeOfTv_set; ++i) {
            if (this.Baza[i].getName().equals(name)) {
                System.out.println(this.Baza[i].getTV_setData());
            }
        }

    }

    public void sellTv_set(int id) {
        for(int i = 0; i < this.sizeOfTv_set; ++i) {
            if (this.Baza[i].getId() == id) {
                this.Baza[i].setisSold(true);
            }
        }

    }

    public void otredaktirovatTV_set(int id, String name, String mark, double price, String HD) {
        for(int i = 0; i < this.sizeOfTv_set; ++i) {
            if (this.Baza[i].getId() == id) {
                this.Baza[i].setName(name);
                this.Baza[i].setMark(mark);
                this.Baza[i].setPrice(price);
                this.Baza[i].setHD(HD);
                this.Baza[i].setName(name);
            }
        }

    }

    public void delete(int id) {
        for(int i = 0; i < this.sizeOfTv_set; ++i) {
            if (this.Baza[i].getId() == id) {
                this.Baza[i].setisDeleted(true);
            }
        }

    }
}
