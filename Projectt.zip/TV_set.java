public class TV_set {
    private int id;
    private String name;
    private String mark;
    private double price;
    private String HD;
    private boolean isSold;
    private boolean isDeleted;

    TV_set() {
    }

    TV_set(int id, String name, String mark, double price, String HD, boolean isSold, boolean isDeleted) {
        this.id = 0;
        this.name = "No name";
        this.mark = "No mark";
        this.price = 0.0D;
        this.HD = "No HD";
        this.isSold = false;
        this.isDeleted = false;
    }

    public int getId()
    {
        return this.id;
    }

    public String getName() {

        return this.name;
    }

    public String getMark() {
        return this.mark;
    }

    public double getPrice() {
        return this.price;
    }

    public String getHD() {
        return this.HD;
    }

    public boolean isSold() {
        return this.isSold;
    }

    public boolean isDeleted() {
        return this.isDeleted;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setHD(String HD) {
        this.HD = HD;
    }

    public void setisSold(boolean sold) {
        this.isSold = sold;
    }

    public void setisDeleted(boolean deleted) {
        this.isDeleted = deleted;
    }

    public boolean getisSold() {
        return this.isSold;
    }

    public boolean getisDeleted() {
        return this.isDeleted;
    }

    public String getTV_setData() {
        return "id: " + this.id + " " + this.name + " " + this.mark + " " + this.price + " " + this.HD;
    }
}