import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Qwer qwer = new Qwer();
        TV_set first = new TV_set();
        first.setId(1);
        first.setName("Grundig");
        first.setMark("H213SR");
        first.setPrice(178000.0D);
        first.setHD("Full");
        qwer.addNewTV_set(first);
        TV_set second = new TV_set();
        second.setId(2);
        second.setName("Samsung");
        second.setMark("Y87HE");
        second.setPrice(470000.0D);
        second.setHD("Ultra");
        qwer.addNewTV_set(second);
        TV_set third = new TV_set();
        third.setId(3);
        third.setName("Sony");
        third.setMark("SH721J");
        third.setPrice(150000.0D);
        third.setHD("Full");
        qwer.addNewTV_set(third);
        TV_set four = new TV_set();
        four.setId(4);
        four.setName("Hisense");
        four.setMark("H43KD3");
        four.setPrice(380000.0D);
        four.setHD("Ultra");
        qwer.addNewTV_set(four);

        while(true) {
            while(true) {
                System.out.println("PRESS [1] TO ADD NEW TV_set");
                System.out.println("PRESS [2] TO LIST TV_set");
                System.out.println("PRESS [3] TO FIND BY NAME");
                System.out.println("PRESS [4] TO SELL TV_set");
                System.out.println("PRESS [5] TO EDIT TV_set DATA");
                System.out.println("PRESS [6] TO DELETE TV_set");
                System.out.println("PRESS [0] TO EXIT");
                int num = sc.nextInt();
                String name;
                String mark;
                double price;
                String HD;
                int id;
                if (num == 1) {
                    System.out.println("Enter id: ");
                    id = sc.nextInt();
                    System.out.println("Enter name: ");
                    name = sc.next();
                    System.out.println("Enter mark: ");
                    mark = sc.next();
                    System.out.println("Enter price: ");
                    price = sc.nextDouble();
                    System.out.println("Enter HD");
                    HD = sc.next();
                    TV_set televizor = new TV_set();
                    televizor.setId(id);
                    televizor.setName(name);
                    televizor.setMark(mark);
                    televizor.setPrice(price);
                    televizor.setHD(HD);
                    qwer.addNewTV_set(televizor);
                } else if (num == 2) {
                    qwer.printAllTV_set();
                } else if (num == 3) {
                    System.out.println("Enter name: ");
                    String Name = sc.next();
                    qwer.iskatPoImeni(Name);
                } else if (num == 4) {
                    qwer.printAllTV_set();
                    System.out.println("Enter id to buy: ");
                    id = sc.nextInt();
                    qwer.sellTv_set(id);
                    System.out.println("Вы успешно купили телевизор");
                } else if (num == 5) {
                    qwer.printAllTV_set();
                    System.out.println("Enter id: ");
                    id = sc.nextInt();
                    System.out.println("Enter new name: ");
                    name = sc.next();
                    System.out.println("Enter new mark: ");
                    mark = sc.next();
                    System.out.println("Enter new price: ");
                    price = sc.nextDouble();
                    System.out.println("Enter new HD: ");
                    HD = sc.next();
                    qwer.otredaktirovatTV_set(id, name, mark, price, HD);
                } else if (num == 6) {
                    System.out.println("Enter id: ");
                    id = sc.nextInt();
                    qwer.delete(id);
                } else {
                    if (num == 0) {
                        return;
                    }

                    System.out.println("Enter number only 0-6");
                }
            }
        }
    }
}
