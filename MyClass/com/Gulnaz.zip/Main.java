package com.company;

import java.awt.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ERPSystem erpSystem = new ERPSystem();
        int number ;

        Restaurant food1 = new Restaurant();
        food1.setId(1);
        food1.setName("Ramen");
        food1.setCalorie(1352.2);
        food1.setCooking_time(40);
        food1.setWeight(400);
        food1.setPrice(800);
        food1.setCountry("Korea");
        erpSystem.addNewFood(food1);

        Restaurant food2 = new Restaurant();
        food2.setId(2);
        food2.setName("Lagman");
        food2.setCalorie(1200);
        food2.setWeight(450);
        food2.setCooking_time(50);
        food2.setPrice(950);
        food2.setCountry("Uigyr");
        erpSystem.addNewFood(food2);

        Restaurant food3 = new Restaurant();
        food3.setId(3);
        food3.setName("Sushi");
        food3.setCalorie(789.54);
        food3.setCooking_time(35);
        food3.setWeight(500);
        food3.setPrice(970);
        food3.setCountry("Japan");
        erpSystem.addNewFood(food3);

        Restaurant food4 = new Restaurant();
        food4.setId(4);
        food4.setName("Lapsha");
        food4.setCalorie(689.24);
        food4.setCooking_time(31);
        food4.setPrice(780);
        food4.setWeight(600);
        food4.setCountry("China");
        erpSystem.addNewFood(food4);

        Restaurant food5 = new Restaurant();
        food5.setId(5);
        food5.setName("Pelmeni");
        food5.setCalorie(769.25);
        food5.setCooking_time(34);
        food5.setWeight(650);
        food5.setPrice(830);
        food5.setCountry("RUS");
        erpSystem.addNewFood(food5);




        while(true){
            System.out.println("PRESS [1] TO ADD NEW FOOD ");
            System.out.println("PRESS [2] TO LIST FOODS");
            System.out.println("PRESS [3] TO FIND FOOD BY NAME");
            System.out.println("PRESS [4] TO EDIT FOOD DATA");
            System.out.println("PRESS [5] TO BUY FOOD");
            System.out.println("PRESS [6] TO DELETE FOOD");
            System.out.println("PRESS [0] TO EXIT");

            number = sc.nextInt();

            if(number == 1){
                System.out.println("Enter id: ");
                int id = sc.nextInt();
                System.out.println("Enter name: ");
                String name = sc.next();
                System.out.println("Enter calorie: ");
                double calorie = sc.nextDouble();
                System.out.println("Enter weight: ");
                double weight = sc.nextDouble();
                System.out.println("Enter country: ");
                String country = sc.next();
                System.out.println("Enter price: ");
                double price = sc.nextDouble();
                System.out.println("Enter cooking time:");
                double cookingTime = sc.nextDouble();

                Restaurant food = new Restaurant();
                food.setId(id);
                food.setName(name);
                food.setWeight(weight);
                food.setCountry(country);
                food.setPrice(price);
                food.setCalorie(calorie);
                food.setCooking_time(cookingTime);
                erpSystem.addNewFood(food);
            }
            else if(number == 2 ){

                erpSystem.printAllFoods();
            }
            else if ( number == 3){ // найти еду по его имемни
                System.out.println("Enter name: ");
                String name = sc.next();
                erpSystem.naiti(name);
            }
            else if (number == 4){  // отредактирование его данные
                System.out.println("Enter id: ");
                int id = sc.nextInt();
                System.out.println("Enter new name");
                String name = sc.next();
                System.out.println("Enter new calorie ");
                double calorie = sc.nextDouble();
                System.out.println("Enter new price");
                double price = sc.nextDouble();
                System.out.println("Enter new country");
                String country = sc.next();
                System.out.println("Enter new weight");
                double weight = sc.nextDouble();
                System.out.println("Enter new cooking time");
                double cookinTime = sc.nextDouble();
                erpSystem.otredaktirovat(id,weight,calorie,price,cookinTime,name,country );
            }
            else if (number == 5){ // buy food
                erpSystem.printAllFoods();
                System.out.println("Enter id: ");
                int id = sc.nextInt();
                erpSystem.buyFood(id);
                System.out.println("Вы успешно покупали еду");

            }
            else if (number == 6){ // delete food
                System.out.println("Enter id to delete the food: ");
                int id = sc.nextInt();
                erpSystem.deleteFood(id);

            }
            else if (number == 0){
                break;
            }
            else{
                System.out.println("Error");
            }





        }


    }



}