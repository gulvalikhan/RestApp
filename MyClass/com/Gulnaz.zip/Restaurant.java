package com.company;

public class Restaurant {
    private int id;
    private String name;
    private double price;
    private double calorie;
    private String country;
    private double weight;
    private double cooking_time;

    private boolean isDeleted;
    private boolean isSold;


    // Констуктор по умолчанию
    Restaurant(){}

    //  Конструктор с параметрами
    Restaurant(int id,String name,double weight, double price,boolean isDeleted ,boolean isSold,double calorie,String country, double cooking_time){
        this.id=0;
        this.calorie=0;
        this.weight=0;
        this.name="No name";
        this.price=0;
        this.isDeleted=false;
        this.isSold=false;
        this.country="No data";
        this.cooking_time=0;}

    // getter  и setter

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public void setIsDeleted(boolean isDeleted){
        this.isDeleted=isDeleted;
    }
    public boolean getIsDeleted(){
        return isDeleted;
    }

    public void setIsSold(boolean isSold) {
        this.isSold = isSold;
    }
    public boolean getIsSold(){
        return isSold;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getCalorie() {
        return calorie;
    }

    public void setCalorie(double calorie) {
        this.calorie = calorie;
    }

    public double getCooking_time() {
        return cooking_time;
    }

    public void setCooking_time(double cooking_time) {
        this.cooking_time = cooking_time;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public String getFoodsData(){
        return "id: "+id+" "+name+",calorie: "+calorie+",weight: "+weight +". National food:"+country+",cooking time"+cooking_time +" PRICE: "+price ;
    }


}
