package com.company;

import javax.xml.namespace.QName;

public class ERPSystem {

    private Restaurant[] memory = new Restaurant[1000];
    private int sizeOfFoods = 0;

    public void addNewFood(Restaurant food){
        memory[sizeOfFoods] = food;
        sizeOfFoods++;
    }
    public void printAllFoods(){
        for(int i=0;i<sizeOfFoods;i++){
            if(memory[i].getIsDeleted()==false && memory[i].getIsSold()== false){
                System.out.println(memory[i].getFoodsData());
            }
        }

    }

    public void naiti(String name){
        for(int i=0;i<sizeOfFoods;i++){
            if(memory[i].getName().equals(name))    {
                System.out.println(memory[i].getFoodsData());
            }

        }

    }

    public void otredaktirovat(int id,double weight,double calorie, double price, double cookingTime, String name , String country){
        for(int i=0;i<sizeOfFoods;i++){
            if(memory[i].getId()==id){
                memory[i].setCalorie(calorie);
                memory[i].setPrice(price);
                memory[i].setCooking_time(cookingTime);
                memory[i].setCountry(country);
                memory[i].setWeight(weight);
                memory[i].setName(name);

            }

        }

    }

    public void buyFood(int id){
        for(int i=0;i<sizeOfFoods;i++){
            if(memory[i].getId()==id){
                memory[i].setIsSold(true);
            }
        }

    }
    public void deleteFood(int id ){
        for(int i=0;i<sizeOfFoods;i++){
            if(memory[i].getId() == id ){
                memory[i].setIsDeleted(true);
            }
        }

    }





}
