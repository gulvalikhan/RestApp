package com.company;

public class BasicSystem {
    private Telephones[] memory = new Telephones[1000];
    private int count = 0;

    public void addNewTelephones(Telephones telephone) {
        memory[count] =telephone;
        count++;
    }

    public void printAllTelephones() {
        for (int i = 0; i < count; i++) {
            if (memory[i].getIsDeleted() == false) {
                System.out.println(memory[i].getTelephonesData());
            }
        }
    }

    public void findByName(String name) {
        for (int i = 0; i < count; i++) {
            if (memory[i].getName().equals(name)) {
                System.out.println(memory[i].getTelephonesData());
            }
        }
    }

    public void editTelephoneData(int id, String name, String model, double price, int year) {
        for (int i = 0; i < count; i++) {
            if (memory[i].getId() == id) {
                memory[i].setName(name);
                memory[i].setModel(model);
                memory[i].setPrice(price);
                memory[i].setYear(year);

            }
        }

    }

    public void deleteTelephones(int id) {
        for (int i = 0; i < count; i++) {
            if (memory[i].getId() == id) {
                memory[i].setIsDeleted(true);
            }

        }
    }


    public void comparisonYearSize(int year) {
        for (int i = 0; i < count; i++) {
            if (memory[i].getYear() > year) {
                System.out.println(memory[i].getTelephonesData());
            }

        }

    }


    public void comparisonPrice(int price) {
        for (int i = 0; i < count; i++) {
            if (memory[i].getPrice() < price) {
                System.out.println(memory[i].getTelephonesData());
            }
        }
    }
}