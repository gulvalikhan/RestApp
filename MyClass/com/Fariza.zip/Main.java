package com.company;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
        BasicSystem ownSys = new BasicSystem();
        Telephones telephones1 = new Telephones();
        telephones1.setId(1);
        telephones1.setName("Samsung A5");
        telephones1.setModel("Android");
        telephones1.setPrice(90000);
        telephones1.setYear(2021);
        ownSys.addNewTelephones(telephones1);

        Telephones telephones2 = new Telephones();
        telephones2.setId(2);
        telephones2.setName("Iphone 8");
        telephones2.setModel("IOS");
        telephones2.setPrice(160000);
        telephones2.setYear(2020);
        ownSys.addNewTelephones(telephones2);

        Telephones telephones3 = new Telephones();
        telephones3.setId(3);
        telephones3.setName("Samsung S20");
        telephones3.setModel("Android");
        telephones3.setPrice(340000);
        telephones3.setYear(2021);
        ownSys.addNewTelephones(telephones3);

        Telephones telephones4 = new Telephones();
        telephones4.setId(4);
        telephones4.setName("Iphone 13");
        telephones4.setModel("IOS");
        telephones4.setPrice(770000);
        telephones4.setYear(2022);
        ownSys.addNewTelephones(telephones4);

        Telephones telephones5 = new Telephones();
        telephones5.setId(5);
        telephones5.setName("Samsung A51");
        telephones5.setModel("Android");
        telephones5.setPrice(110000);
        telephones5.setYear(2020);
        ownSys.addNewTelephones(telephones5);


        while (true) {

            System.out.println("PRESS [1] TO ADD NEW TELEPHONES");
            System.out.println("PRESS [2] TO LIST ALL TELEPHONES");
            System.out.println("PRESS [3] TO FIND TELEPHONE BY NAME");
            System.out.println("PRESS [4] TO EDIT TELEPHONE BY ID");
            System.out.println("PRESS [5] TO DELETE TELEPHONE");
            System.out.println("PRESS [6] TO COMPARISON TELEPHONE");
            System.out.println("PRESS [0] TO ADD NEW TELEPHONE");

            num = sc.nextInt();

            if (num == 1) {
                System.out.println("Enter id: ");
                int id = sc.nextInt();
                System.out.println("Enter name: ");
                String name = sc.next();
                System.out.println("Enter model: ");
                String model = sc.next();
                System.out.println("Enter price: ");
                int price = sc.nextInt();
                System.out.println("Enter year: ");
                int year = sc.nextInt();


                Telephones telephone = new Telephones();
                telephone.setId(id);
                telephone.setName(name);
                telephone.setModel(model);
                telephone.setPrice(price);
                telephone.setYear(year);


                ownSys.addNewTelephones(telephone);
            } else if (num == 2) {
                ownSys.printAllTelephones();
            } else if (num == 3) {
                System.out.println("Enter name: ");
                String name = sc.next();
                ownSys.findByName(name);

            } else if (num == 4) {
                System.out.println("Enter id: ");
                int id = sc.nextInt();
                System.out.println("Enter new name: ");
                String name = sc.next();
                System.out.println("Enter new model: ");
                String model = sc.next();
                System.out.println("Enter new Price: ");
                int price = sc.nextInt();
                System.out.println("Enter new Year: ");
                int year = sc.nextInt();
                ownSys.editTelephoneData(id, name, model, price, year);


            } else if (num == 5) { // delete
                System.out.println("Enter id");
                int id = sc.nextInt();
                ownSys.deleteTelephones(id);
                System.out.println("Телефон успешно удален");
            }else if (num == 6) {
                System.out.println("PRESS [1] TO COMPARISON Year ");
                System.out.println("PRESS [2] TO COMPARISON PRICE");
                int choice = sc.nextInt();

                if (choice == 1) {
                    System.out.println("Enter Year: ");
                    int year = sc.nextInt();
                    ownSys.comparisonYearSize(year);

                } else if (choice == 2) {
                    System.out.println("Enter memory price: ");
                    int price = sc.nextInt();
                    ownSys.comparisonPrice(price);

                }

            }

            if (num == 0) {
                break;
            } else {
                System.out.println("Готова");
            }
        }

    }
}