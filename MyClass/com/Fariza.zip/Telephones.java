package com.company;

public class Telephones {
    private int id;
    private String name;
    private String model;
    private double price;
    private int year;
    private boolean isDeleted;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {

        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {

        this.price = price;
    }


    public int getYear() {
        return year;
    }

    public void setYear(int Year) {
        this.year = year;
    }


    public void setIsDeleted(boolean deleted) {

        isDeleted = deleted;
    }

    public boolean getIsDeleted() {

        return isDeleted;
    }


    // Конструктур по умолчанию
    Telephones() {
    }

    // Конструктур с параметрами
    Telephones(String name, String model, double price, int year, boolean isDeleted) {
        this.id = 0;
        this.name = "No name";
        this.model = "No mark";
        this.price = 0;
        this.isDeleted = false;
        this.year = 0;
    }

    // методы
    public String getTelephonesData() {
        return  "Name:" + name +
                " Model:" + model +
                " Price: " + price +
                " Year:" + year;
    }


}