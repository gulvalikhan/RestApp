<html>
    <head>
        <style> 
        
    </style>
        <title>2nshy tapsyrma</title>
        <body>

        <h1> 2 tapsyrma </h1>
        <table style = 'border-spacing: 20px;' >
        <thead>
            <tr>
                  <th> ID </th>
                  <th> NAME </th>
                  <th> SURNAME </th>
            </tr>
        </thead>
        <tbody>
            <?php
              for($i=1;$i<=10;$i++) {
                  echo "<tr><td>".$i. "</td><td> NAME ".$i."</td><td> SURNAME".$i."</td></tr>";

              }
            ?>
            <tbody>
            </table>


        </body>
    </head>
</html>