
<table width="" cellspacing="0.5px" cellpadding="0.5px" border="1px">
            <?php

            for ($row=1; $row<=50; $row++){
                echo "<tr>";
            for ($col=1; $col<=50; $col++){
                $res = $row + $col;

                if ($res % 2 == 0){
                    echo "<td height=0.8px width=0.8px bgcolor=#ffff00></td>";
            }
                else{
                    echo "<td height=10px width=10px bgcolor=#000000 ></td>";
                }
            }
                echo "</tr>";
        }
    ?>
    