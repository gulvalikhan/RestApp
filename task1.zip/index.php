<?php 

     for($i=1;$i<21;$i++) {

        echo "<h1> Hello BITLAB " .$i."</h1>";
     }


?>