package kz.chrome.keyapp.joom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoomApplicationTests {

	@Test
	void contextLoads() {
	}

}
