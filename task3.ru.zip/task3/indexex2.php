<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Zakaz FOOD</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<div class="container" method="post" action="Resultex2.php">
	<div class="form-icon">	
	<form method="post" action="Resultex2.php">
  <div class="col-sm-10">
    <label>Client Name</label>
    <input type="text" name="name" class="form-control" aria-describedby="emailHelp" placeholder="Enter Name">
  </div>
  <div class="col-sm-10">
    <label>Client surname</label>
    <input type="text" name="surname" class="form-control" placeholder="Enter Surname">
  </div>
  <div class="col-sm-10">
    <label class="form-label" >Food </label>
   <select class="form-select" name="food" aria-label="Default select example">
  <option selected value="Pizza">Pizza - 1100 KZT</option>
  <option value="Chikens">Chikens - 1200 KZT</option>
  <option value="Manty">Manty - 700 KZT</option>
  <option value="Lagman">Lagman - 800 KZT</option>
</select>
  </div>
  <button type="submit" class="btn btn-dark">ORDER FOOD</button>
</form>
</div>
</div>
</body>
</html>