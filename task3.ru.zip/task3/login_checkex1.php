<?php 

	if($_SERVER['REQUEST_METHOD']==='POST'){

		if(isset($_POST['email']) && isset($_POST['password'])){

			require_once 'regesex1.php';

			$found = false;

			foreach($users as $user){

				if($user['email']===$_POST['email'] && $user['password']===$_POST['password']){

					$found = true;
					break;

				}

			}else{

				header("Location:regesex1.php?error");

			}


		}else{

			header("Location:regesex1.php");

		}

	}else{

		header("Location:regesex1.php"); 
	}

?>