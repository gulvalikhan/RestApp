<div class = "container">
            <div class = "row">
                <div class = "col-20 bg-dark py-3">
                    <h6 class = "text-center text-light">
                        Copyright &copy; 2022. All Rigths Reserved.
                    </h6>
                </div>
            </div>
        </div>