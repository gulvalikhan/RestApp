<?php

    if($_SERVER['REQUEST_METHOD']==='GET'){

        $name = $_GET['user_name'];
        $surname = $_GET['user_surname'];
        $age = $_GET['user_age'];
        $city = $_GET['user_city'];

        echo "<h1>NAME: $name</h1>";
        echo "<h1>SURNAME: $surname</h1>";
        echo "<h1>AGE: $age</h1>";
        echo "<h1>CITY: $city</h1>";
    }


?>