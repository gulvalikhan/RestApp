<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            .x{
                width: 300px;
                height: 30px; 
                border-radius: 5px;  
            }
            .y{
                width: 150px;
                height: 30px; 
                background: #00FF00;
            }
        </style>
    </head>
    <body>
        <form action="ex4check.php" method="get">
            NAME: <input class="x" type="text" name="user_name" required><br>
            SURNAME: <input class="x" type="text" name="user_surname" required><br>
            AGE: <input class="x" type="number" name="user_age" required><br>
            CITY: <select class="x" name="user_city">
                <option value="Almaty">Almaty</option>
                <option value="Astana">Astana</option>
                <option value="Shymkent">Shymkent</option>
            </select><br>
            <input type="submit" value="SEND" class="y">
        </form>
    </body>
</html>