<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "cclkex1.php";
        ?>
    </head>
    <body>
    <?php
            include "navbarex1.php";
        ?>
         <div class = "container mt-3">
           <div class = "row py-3">
                <h2 class = "text-center">WELCOME TO BITLAB SHOP</h2>
            </div>
        </div>

       <div class = "container mt-3">
           <div class = "row py-3">
                <div class = "col-3">
                    <div class="card">
                    <div class="card-header">
                        Macbook Pro 2020
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$1499.99</h5>
                            <p class="card-text">256 GB SSD<br> Intel Core i7</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOw</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                        Asus Tuf Gaming
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$999.99</h5>
                            <p class="card-text">16 GB RAM <br> AMD Ryzen 5</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                        Apple Iphone 12 Pro
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$1099.99</h5>
                            <p class="card-text">6 GB RAM  <br> Super Retina XDR OLED Display</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                        XIAOMI Redmi Note 8
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$199.99</h5>
                            <p class="card-text">6 GB RAM<br> Android 9 Pie</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                    XIAOMI Redmi Note 10
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$299.99</h5>
                            <p class="card-text">8 GB RAM <br> Android 11</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                        MSI Prestige 15
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$1999.9</h5>
                            <p class="card-text">1024 GB Memory <br> Intel Core i7</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                        Samsung Galaxy A71
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$149.99</h5>
                            <p class="card-text">128GB Memory</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY  NOW</a>
                        </div>
                    </div>
                </div>
                <div class = "col-3">
                <div class="card">
                    <div class="card-header">
                    headphones
                    </div>
                    <div class="card-body">
                            <h5 class="card-title">$200.99</h5>
                            <p class="card-text"> Color White-pink</p>
                            <a href="detailsex1.php" class="btn btn-success">BUY NOW</a>
                        </div>
                    </div>
                </div>
           </div>
       </div>
        <?php
            include "footerex1.php";       
        ?>
    </body>
</html>