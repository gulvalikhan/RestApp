<!DOCTYPE html>
<html>
	<head>
		<?php
            include "cclkex1.php";
        ?>
	</head>
	<body>
        <?php
            include "navbarex1.php";
        ?>
		<?php
			if(isset($_GET['error'])){
				echo "<h4 style = 'color:red;'>Incorrect email or password</h4>";
			}
		?>
                <form action="login_checkex1.php" method="post">
                            EMAIL : <input type="email" name="email" required><br>
                            PASSWORD : <input type="password" name="password" required><br>
                            <button>SIGN IN</button>
                         </form>
	</body>
</html>