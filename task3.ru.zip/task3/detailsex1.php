<!DOCTYPE html>
<html lang="en">
    <head>
    <?php
                include "cclkex1.php";
            ?>
    </head>
    <body>
        <?php
            include "navbarex1.php";
        ?>
        <form action="detailsex1.php" method="get">
       
        <?php 

        $users = array();

            $users[] = array("email"=>"@gmail.com", "password"=>"qweqwe");
            $users[] = array("email"=>"@gmail.com", "password"=>"asdasd");
            $users[] = array("email"=>"@gmail.com", "password"=>"qwerty");
            $users[] = array("email"=>"@gmail.com", "password"=>"zxczxc");
    
        ?>

            <div class="container m-10">
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                             Featured
            </div>
            <div class="card-body">
                            <h5 class="card-title"></h5>
                            <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                            <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>