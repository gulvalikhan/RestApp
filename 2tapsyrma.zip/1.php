<html lang="ru">
<head>
<?php
require "title.php";
?>
</head>
<body>
<?php
require "cinameNews.php";
?>
</body>

</html>