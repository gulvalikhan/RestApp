<?php
$news = array();
$news[0]['title'] = "Cristiano Ronaldo won the Champions League again";
$news[0]['content'] = "Cristiano Ronaldo scored 3 goals in final";
$news[0]['author'] = "John Smith";

$news[1]['title'] = "Leo Messi won the La Liga";
$news[1]['content'] = "Leo Messi scored maximum goal in La Liga";
$news[1]['author'] = "Javier Correa";

$news[2]['title'] = "Real Madrid won European Super Cup";
$news[2]['content'] = "Real Madrid won Atletico in Super Cup final";
$news[2]['author'] = "Alfredo Relano";

$news[3]['title'] = "Portugal won The World Cup 2018";
$news[3]['content'] = "Cristiano Ronaldo won The World Cup 2018";
$news[3]['author'] = "Michele Henry";

$news[4]['title'] = "The Crazy Way Falcon And The Winter Soldier's Anthony Mackie Learned About Captain America 4";
$news[4]['content'] = "Last Friday, Disney+'s The Falcon and the Winter Soldier concluded its six-episode run, and among the major events in the finale was Anthony Mackie's Sam Wilson suiting up as Captain America for the  first time.";
$news[4]['author'] = "Adam Holmes";

$news[5]['title'] = "Star Wars' Mark Hamill Addresses Horrifying Ewok Theory";
$news[5]['content'] = "Most of the time, you're enjoying the movie that you're watching and you're really engrossed in the story,you won't notice those little moments that,perhaps,do not make a great deal of sence. ";
$news[5]['author'] = "Dirk Libbey";

$news[6]['title'] = "Last Man Standing's Kaitlyn Dever Landed A Movie With ER Icon George Clooney";
$news[6]['content'] = "If you're a fan of the soon-to-conclude Last Man Standing, then you're well acquainted with Katlyn Dever ,who's starred as Eve Baxter for the entirety of the Fox series'run be it as part of the main cast or ina recurring capacity.";
$news[6]['author'] = "Adam Holmes";

$news[7]['title'] = "Matthew Mcconaughey reveals The Question He Gets Asked The Most About Acting In";
$news[7]['content'] = "Oscar winner matthew McConaughey is modern Hollywood  royaity.His decades -long career has served as an inspiration to many up-and-coming actors.";
$news[7]['author'] = "Adreon Patterson";

$news[8]['title'] = "This Policy Undermines Trust’: San Francisco DA Says Cops Ran Rape Victim’s DNA to Arrest Her";
$news[8]['content'] = "San Francisco District Attorney Chesa Boudin calls on police to end alleged ‘illegal’ practice of searching victims’ DNA database for potential suspects in other crimes";
$news[8]['author'] = "Andrea Marks";

$news[9]['title'] = "ICM’s Jeff Barry Joins Range Media Partners as International TV Head";
$news[9]['content'] = "Longtime ICM Partners agent Jeff Barry has joined Range Media Partners, where he will head up the company’s international TV department.";
$news[9]['author'] = "Matt Donnelly";

$news[10]['title'] = "Sarah Palin Loses Again: Jury Rejects Defamation Suit Against ‘New York Times’";
$news[10]['content'] = "Prior to the unanimous decision, the judge overseeing the case had already decided to dismiss the suit.";
$news[10]['author'] = "Jon Blistein";

$news[11]['title'] = "‘The Dropout’ Trailer: Amanda Seyfried Is Elizabeth Holmes in Hulu Miniseries";
$news[11]['content'] = "The trial of Elizabeth Holmes recently concluded, but don’t expect to stop hearing
about the former Theranos CEO any time soon. Hollywood is enthralled by the story of the tech icon, who was
recently found guilty of four charges of defrauding investors, and several projects about her downfall are
in development.";
$news[11]['author'] = "Christian Zilko";
?>