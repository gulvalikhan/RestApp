<html lang="ru">
<head>
    <?php
    require "title.php"
    ?>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <?php
            require "Navbar.php";
            ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12 bg-light py-2">
            <?php
            $news = array();
            include "db.php";
            for ($i = 0; $i < 4; $i++) {
                echo "<div class='card w-100 bg-dark bg-opacity-25'>
                            <div class='card-body'><h5 class='card-title'>" . $news[$i]['title'] . "</h5>
                                <p class='card-text'>" . $news[$i]['content'] . "</p>
                                   by <b>" . $news[$i]['author'] . "</b>
                            </div>
                      </div>
                            <p>
                           </p>";
            }
            ?>
        </div>
    </div>
</div>
</body>
</html>