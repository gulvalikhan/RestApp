<html lang="ru">
<head>
    <?php
    require "cclk.php"
    ?>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-12">
            <?php
            require "navbar1.php";
            ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-21 bg-light py-2">
            <?php
            $news = array();
            include "list.php";
            
            ?>
            
        </div>
    </div>
</div>
<div class="container">
      <div class="row">
        <div class="col-12 bg-dark py-3">
          <h4 class="text-center text-light ">Copyright 2021, All Rights Reserved</h4>
        </div>
      </div>
	</div>
</body>
</html>