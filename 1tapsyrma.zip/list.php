       <table class="table">
  <thead>
    <tr>
      <th scope="col">NO</th>
      <th scope="col">Full name</th>
      <th scope="col">Details</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td >Gulbarshyn Valikhan</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td >Bukharova Fariza</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td >Zhanel Amangeldy</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td >Madina Kenzhe</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
      <tr>
      <th scope="row">4</th>
      <td >Enlik Mukanbay</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td >Aiaulym Nurakyn</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">6</th>
      <td >Nuray Izbasar</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">7</th>
      <td >Gulnaz Kaldarbek</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">8</th>
      <td >Gulnaz Lesbay</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">9</th>
      <td >Amangeldy Muratkhan</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    <tr>
      <th scope="row">10</th>
      <td >Men Gulbarshyn</td>
      <td><button type="button" class="btn btn-primary">Details</button></td>
    </tr>
    </tr>
  </tbody>

  
</table>
