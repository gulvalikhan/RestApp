<?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <div col-6 mx-auto>
                        <form action="toaddproduct.php" method="post">
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>NAME: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" name="name" required placeholder="Insert name">
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>MANUFACTURER: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" name="manufacturer" required placeholder="Insert manufacturer">
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>PRICE: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="number" name="price" required placeholder="Insert price">
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <button class="btn btn-success">ADD PRODUCT</button>
                                </div>
                            </div>
                        </form>
                    </div>
                 </div>
             </div>
         </div>
    </body>
</html>