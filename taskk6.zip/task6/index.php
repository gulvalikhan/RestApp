        <?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <table class="tabbe table striped">
                       <thead>
                            <tr>
                                <td>ID</td>
                                <td>NAME</td>
                                <td>SURNAME</td>
                                <td>SALARY</td>
                                <td>DEPARTMENT</td>
                                <td width="7%">DETAILS</td>
                            </tr>
                       </thead>
                       <tbody>
                            <?php
                            
                                $employee = getEmployee();
                                if($employee!=null){
                                    foreach($employee as $employee){
                            ?>
                                <tr>
                                    <td><?php echo $items['id'];?></td>
                                    <td><?php echo $items['name'];?></td>
                                    <td><?php echo $items['surname'];?></td>
                                    <td><?php echo $items['salary'];?></td>
                                    <td><?php echo $items['department'];?></td>
                                    <td><a href="details.php?id=<?php echo $employee['id'];?>" class="btn btn-primary btn-sm">DETAILS</a></td>

                                </tr>
                                <?php
                                        }
                                    }
                                ?>
                       </tbody>
                    </table>
                 </div>
             </div>
         </div>
    </body>
</html>