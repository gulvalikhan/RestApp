<?php

    $redirect = "index.php";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        require_once 'db.php';

        if(isset($_POST['id'])){

           $product = getProduct($_POST['id']);

           if($product!=null){

            deleteProduct($_POST['id']);

           }
        }

    }
    
    header("Location:$redirect");
  
?>