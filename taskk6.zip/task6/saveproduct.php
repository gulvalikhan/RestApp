<?php

    $redirect = "index.php";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        require_once 'db.php';

        if(isset($_POST['id']) && isset($_POST['name']) && isset($_POST['manufacturer']) && isset($_POST['price'])){

           $product = getProduct($_POST['id']);

           if($product!=null){

            updateProduct($_POST['id'], $_POST['name'], $_POST,['manufacturer'], $_POST['price']);
                $redirect = "details.php?id=".$_POST['id'];
           }
        }

    }
    
    header("Location:$redirect");
  
?>