<?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <div col-6 mx-auto>
                        <?php
                            
                            if(isset($_GET['id']) ){

                                $employee = getEmployee($_GET['id']);

                                if($employee!=null){

                                
                        
                        ?>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>NAME: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" value="<?php echo $employee['name'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>SURNAME: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" value="<?php echo $employee['surname'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>SALARY: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="number" value="<?php echo $employee['salary'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>DEPARTMENT: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" value="<?php echo $employee['department'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#saveemployee">
                                    EDIT EMPLOYEE
                                </button>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#demployee">
                                    DELETE EMPLOYEE
                                </button>
                                </div>
                            </div>
                                <div class="modal fade" id="saveemployee" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                          <form action="saveemployee" method="post">
                                          <input type="hidden" name="id" value="<?php echo $employee['id'];?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel">EDIT EMPLOYEE</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>NAME</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="text" name="name" class="form-control" placeholder="Insert name" required value
                                                            ="<?php echo $employee['name'];?>">
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>SURNAME</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="number" name="surname" class="form-control" placeholder="Insert surname" required value
                                                            ="<?php echo $employee['price'];?>">
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>SALARY</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="number" name="salary" class="form-control" placeholder="Insert salary" required value
                                                            ="<?php echo $employee['salary'];?>">
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>DEPARTMENT</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="text" name="department" class="form-control" placeholder="Insert department" required value
                                                            ="<?php echo $employee['department'];?>">
                                                        </div>
                                                    </div>
                                                    </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">CLOSE</button>
                                                    <button class="btn btn-success">SAVE</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="demployee" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="deleteemployee.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $employee['id'];?>">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">Confirm delete</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                ARE YOU SURE?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
                                                <button class="btn btn-danger">YES</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                                }
                            ?>
                    </div>
                 </div>
             </div>
         </div>
    </body>
</html>