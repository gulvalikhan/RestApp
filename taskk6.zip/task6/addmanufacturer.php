<?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <div col-6 mx-auto>
                        <form action="toaddmanufacturer.php" method="post">
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>NAME: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" name="name" required placeholder="Insert name">
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>CODE: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" name="code" required placeholder="Insert code">
                                </div>
                            </div>
                            
                            <div class="row mt-3">
                                <div class="col-12">
                                    <button class="btn btn-success">ADD MANUFACTURER</button>
                                </div>
                            </div>
                        </form>
                    </div>
                 </div>
             </div>
         </div>
    </body>
</html>