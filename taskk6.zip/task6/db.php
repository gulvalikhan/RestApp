<?php

    try{

        $connection = new PDO("mysql:host=localhost;dbname=fariza_kz_db", "root", "");
    
    }catch(Exception $e){

        echo "<h5  style = 'color: red;'>".$e->getMessege()."</h5>";
    }

    function getEmployee(){

        global $connection;

        $query = $connection->prepare("SELECT * FROM employee");

        $query->execute();

        $result = $query->fetchAll();

        return $result;
    }

    function addEmployee($name, $surname, $department){

        global $connection;

        $query = $connection->prepare("
            INSERT INTO employee(id, name, surname, department)
            VALUES(NULL, :n, :p, :m)
        ");

        $query->execute(array("n"=>$name, "p"=>$surname, "m"=>$department));

    }

    function getEmp($id){

        global $connection;

        $query = $connection->prepare("SELECT * FROM items WHERE id = :id");
        $query->execute(array("id"=>$id));
        $result = $query->fetch();


        return $result;
    }

    function updateEmployee($id, $name, $surname, $department){

        global $connection;

        $query = $connection->prepare("
            UPDATE employee SET name = :n, surname = :p, department = :m WHERE id = :i
        ");

        $query->execute(array("n"=>$name, "p"=>$surname, "m"=>$department, "i"=>$id));

    }

    function deleteEmployee($id){

        global $connection;

        $query = $connection->prepare("
            DELETE FROM items WHERE id = :i 
        ");

        $query->execute(array("i"=>$id));

    }
?>