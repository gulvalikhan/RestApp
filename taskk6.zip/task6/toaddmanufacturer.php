<?php

    $redirect = "index.php";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){

        include "db.php";

        if(isset($_POST['name']) && isset($_POST['code'])){

          

            addProduct($_POST['name'], $_POST['code']);

        }
    }
      header("Location:$redirect");  

?>