<?php

    try{

        $connection = new PDO("mysql:host=localhost;dbname=gul", "root", "");
    
    }catch(Exception $e){

        echo "<h5  style = 'color: red;'>".$e->getMessege()."</h5>";
    }

    function getProduct(){

        global $connection;

        $query = $connection->prepare("SELECT * FROM product");

        $query->execute();

        $result = $query->fetchAll();

        return $result;
    }

    function addProduct($name, $manufacturer, $price){

        global $connection;

        $query = $connection->prepare("
            INSERT INTO product(id, name, manufacturer, price)
            VALUES(NULL, :n, :p, :m)
        ");

        $query->execute(array("n"=>$name, "m"=>$manufacturer, "p"=>$price));

    }

    function getProducts($id){

        global $connection;

        $query = $connection->prepare("SELECT * FROM product WHERE id = :id");
        $query->execute(array("id"=>$id));
        $result = $query->fetch();


        return $result;
    }

    function updateProduct($id, $name, $manufacturer, $price){

        global $connection;

        $query = $connection->prepare("
            UPDATE product SET name = :n,manufacturer = :m, price = :p  WHERE id = :i
        ");

        $query->execute(array("n"=>$name, "m"=>$manufacturer, "p"=>$price, "i"=>$id));

    }

    function deleteProduct($id){

        global $connection;

        $query = $connection->prepare("
            DELETE FROM product WHERE id = :i 
        ");

        $query->execute(array("i"=>$id));

    }
?>