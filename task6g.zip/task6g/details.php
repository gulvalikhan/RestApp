<?php
            require_once 'db.php';
        ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            include "head.php";
        ?>
    </head>
    <body>
         <?php
            include "navbar.php";
         ?>
         <div class="container">
             <div class ="row mt-3">
                 <div class="col-12">
                    <div col-6 mx-auto>
                        <?php
                            
                            if(isset($_GET['id']) ){

                                $product = getProduct($_GET['id']);

                                if($product!=null){

                                
                        
                        ?>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>NAME: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" value="<?php echo $product['name'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>MANUFACTURER: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="text" value="<?php echo $product['manufacturer'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                    <label>PRICE: </label>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                  <input class="form-control" type="number" value="<?php echo $product['price'];?>" readonly>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-12">
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#saveproduct">
                                    EDIT PRODUCTS
                                </button>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#dproduct">
                                    DELETE PRODUCTS
                                </button>
                                </div>
                            </div>
                                <div class="modal fade" id="saveproduct" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                          <form action="saveproduct.php" method="post">
                                          <input type="hidden" name="id" value="<?php echo $product['id'];?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel">EDIT PRODUCTS</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>NAME</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="text" name="name" class="form-control" placeholder="Insert name" required value
                                                            ="<?php echo $product['name'];?>">
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>MANUFACTURER</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="text" name="manufacturer" class="form-control" placeholder="Insert manufacturer" required value
                                                            ="<?php echo $product['manufacturer'];?>">
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label>PRICE</label>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <div class="col-12">
                                                            <input type="number" name="price" class="form-control" placeholder="Insert price" required value
                                                            ="<?php echo $product['price'];?>">
                                                        </div>
                                                    </div>
                                                    </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">CLOSE</button>
                                                    <button class="btn btn-success">SAVE</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="ditems" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="deleteproduct.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $product['id'];?>">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="staticBackdropLabel">Confirm delete</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                ARE YOU SURE?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
                                                <button class="btn btn-danger">YES</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                                }
                            ?>
                    </div>
                 </div>
             </div>
         </div>
    </body>
</html>